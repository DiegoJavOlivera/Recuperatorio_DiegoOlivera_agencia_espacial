/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package sistemaexpedicionesespaciales;

/**
 *
 * @author Diego
 */
public class CapacidadMaxException extends RuntimeException{
    private final static String MESSAGE = "La capacidad del carguero no es la correcta.";
    /**
     * Creates a new instance of <code>CapacidadMaxException</code> without
     * detail message.
     */
    public CapacidadMaxException() {
        super(MESSAGE);
    }

    /**
     * Constructs an instance of <code>CapacidadMaxException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public CapacidadMaxException(String msg) {
        super(msg);
    }
}
