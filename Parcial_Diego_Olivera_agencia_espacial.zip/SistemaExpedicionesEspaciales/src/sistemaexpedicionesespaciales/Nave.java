/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaexpedicionesespaciales;

import java.util.Objects;

/**
 *
 * @author Diego
 */
public abstract class Nave {
    private String nombre;
    private int capacidadTripulacion;
    private int anioLanzamiento;

    public Nave(String nombre, int capacidadTripulacion, int anioLanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.anioLanzamiento = anioLanzamiento;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCapacidadTripulacion() {
        return capacidadTripulacion;
    }


    public int getAnioLanzamiento() {
        return anioLanzamiento;
    }

    @Override
    public String toString() {
        return "Nave{" + "nombre: " + nombre + ", capacidad de tripulacion: " + capacidadTripulacion + ", anio de lanzamiento: " + anioLanzamiento;
    }

    @Override
    public int hashCode(){
        return Objects.hash(anioLanzamiento, nombre);
    }
        
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        Nave other = (Nave) o;

        return other.anioLanzamiento == anioLanzamiento
                && other.nombre.equals(nombre);
    }
           
}
