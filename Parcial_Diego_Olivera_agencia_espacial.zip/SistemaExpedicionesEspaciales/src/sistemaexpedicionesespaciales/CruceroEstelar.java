/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaexpedicionesespaciales;

/**
 *
 * @author Diego
 */
public class CruceroEstelar extends Nave{
    private int cantidadPasajeros;

    public CruceroEstelar(String nombre, int capacidadTripulacion , int anioLanzamiento,int cantidadPasajeros) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.cantidadPasajeros = verificarCantidadPasajeros(cantidadPasajeros);
    }

    private int verificarCantidadPasajeros(int pasajeros){
        if (pasajeros < 0) {
            throw new IllegalArgumentException("La capacidad de Pasajeros no puede ser negativa");
        }
        return pasajeros;
    }
    
    @Override
    public String toString() {
        return super.toString() + " Cantidad Pasajeros" + cantidadPasajeros + '}';
    }

    
    
}
