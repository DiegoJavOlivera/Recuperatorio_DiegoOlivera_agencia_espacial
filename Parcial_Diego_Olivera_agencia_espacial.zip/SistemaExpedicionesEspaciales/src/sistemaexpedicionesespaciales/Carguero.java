/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaexpedicionesespaciales;

/**
 *
 * @author Diego
 */
public class Carguero extends Nave implements Exploracion{
    private double capacidadCarga;
    private static final int MAX_CARGA = 500;
    private static final int MIN_CARGA = 100;

    public Carguero( String nombre, int capacidadTripulacion, int anioLanzamiento, double capacidadCarga) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.capacidadCarga = verificarCapacidadCarga(capacidadCarga);
    }
    
    private double verificarCapacidadCarga(double carga){
        if(carga < MIN_CARGA || carga > MAX_CARGA){
            throw new IllegalArgumentException("La capacidad de carga debe estar entre " + MIN_CARGA + " y " + MAX_CARGA + " toneladas.");
        } 
        return carga;
    }
            
    
    public double getCapacidadCarga() {
        return capacidadCarga;
    }
    @Override
    public String toString() {
        return super.toString() + " capacidad Carga=" + getCapacidadCarga() + '}';
    }
    

    @Override
    public void explorar() {
        System.out.println(getNombre() + " nave carguera inicio una exploracion.");
    }
    
}
