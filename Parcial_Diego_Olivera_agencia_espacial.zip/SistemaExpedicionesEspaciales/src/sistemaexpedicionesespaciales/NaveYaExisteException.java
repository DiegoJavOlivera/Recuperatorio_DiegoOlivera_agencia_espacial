/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package sistemaexpedicionesespaciales;

/**
 *
 * @author Diego
 */
public class NaveYaExisteException extends RuntimeException{
    private final static String MESSAGE = "La nave que intentas agregar ya existe en la agencia.";
    /**
     * Creates a new instance of <code>NaveYaExisteException</code> without
     * detail message.
     */
    public NaveYaExisteException() {
        super(MESSAGE);
    }

    /**
     * Constructs an instance of <code>NaveYaExisteException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public NaveYaExisteException(String msg) {
        super(msg);
    }
}
