/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemaexpedicionesespaciales;

import java.util.Scanner;

/**
 *
 * @author Diego
 */
public class SistemaExpedicionesEspaciales {


    public static void main(String[] args) {
        Agencia agencia = new Agencia("Space Y");
        
        Scanner scanner = new Scanner(System.in);

        boolean continuar = true;

        if (continuar) {
            System.out.println("Seleccione una opcion:");
            System.out.println("1. Cargar naves sin errores");
            System.out.println("2. Cargar naves con repetidos");
            System.out.println("3. Cargar naves con error en Crucero Estelar");
            System.out.println("4. Cargar naves con error en Cargero");
            System.out.println("5. Salir");
            System.out.println("Ingrese su opcion: ");

            int opcion;
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    try {
                        System.out.println(" sin errores");
                        agencia.agregarNave(new Carguero("Galactica", 300, 2000, 300));
                        agencia.agregarNave(new Carguero("Rocker Truck", 500, 1950, 410));
                        agencia.agregarNave(new CruceroEstelar("Viajes comodos", 700, 2020, 450));
                        agencia.agregarNave(new CruceroEstelar("Super vacaciones", 1000, 2024, 700));
                        agencia.agregarNave(new NaveExploracion("Explorando el espacio", 10, 2015, TipoMision.INVESTIGACION));
                        agencia.agregarNave(new NaveExploracion("Buscando vida", 25, 2018, TipoMision.CONTACTO));
                    } catch (NullPointerException | NaveYaExisteException | IllegalArgumentException e) {
                        System.out.println("Error!: " + e.getMessage());
                    }
                    break;
                    
                case 2:
                    try {
                        System.out.println(" con repetidos ");
                        agencia.agregarNave(new Carguero("Galactica", 300, 2020, 300));
                        agencia.agregarNave(new Carguero("Rocker Heavy", 500, 1950, 450));
                        agencia.agregarNave(new CruceroEstelar("Galactica", 700, 2020, 450));
                        agencia.agregarNave(new CruceroEstelar("Viajes comodos", 700, 2020, 450));
                        agencia.agregarNave(new NaveExploracion("Explorando el espacio", 10, 2015, TipoMision.INVESTIGACION));
                        agencia.agregarNave(new NaveExploracion("Galactica", 25, 2020, TipoMision.CONTACTO));
                    } catch (NullPointerException | NaveYaExisteException | IllegalArgumentException e) {
                        System.out.println("Error!: " + e.getMessage());
                    }
                    break;

                case 3:
                    try {
                        System.out.println(" error en Crucero Estelar ");
                        agencia.agregarNave(new Carguero("Galactica", 300, 2000, 300));
                        agencia.agregarNave(new Carguero("Rocker Truck", 500, 1950, 420));
                        agencia.agregarNave(new CruceroEstelar("Viajes comodos", 700, 2020, -30));
                        agencia.agregarNave(new CruceroEstelar("Super vacaciones", 1000, 2024, 700));
                        agencia.agregarNave(new NaveExploracion("Explorando el espacio", 10, 2015, TipoMision.INVESTIGACION));
                        agencia.agregarNave(new NaveExploracion("Buscando vida", 25, 2018, TipoMision.CONTACTO));
                    } catch (NullPointerException | NaveYaExisteException | IllegalArgumentException e) {
                        System.out.println("Error!: " + e.getMessage());
                    }
                    break;
                    
                case 4:
                    try {
                        System.out.println(" error en Carguero ");
                        agencia.agregarNave(new Carguero("Perla Voladora", 300, 2000, 453));
                        agencia.agregarNave(new Carguero("Rocker Truck", 500, 1950, 4600));
                        agencia.agregarNave(new CruceroEstelar("Viajes comodos", 700, 2020, 800));
                        agencia.agregarNave(new CruceroEstelar("Super vacaciones", 1000, 2024, 700));
                        agencia.agregarNave(new NaveExploracion("Explorando el espacio", 10, 2015, TipoMision.INVESTIGACION));
                        agencia.agregarNave(new NaveExploracion("Buscando vida", 25, 2018, TipoMision.CONTACTO));
                    } catch (NullPointerException | NaveYaExisteException | IllegalArgumentException e) {
                        System.out.println("Error!: " + e.getMessage());
                    }
                    break;

                case 5:
                    continuar = false;
                    break;
            }
        }

        System.out.println("______________________________________________________________");
        agencia.mostrarNaves();
        System.out.println("______________________________________________________________");
        agencia.iniciarExploracion();
        
    }
    
}
