/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaexpedicionesespaciales;

import java.util.ArrayList;

/**
 *
 * @author Diego
 */
public class Agencia {
    private String nombre;
    private ArrayList<Nave> navesEspaciales;

    public Agencia(String nombre) {
        this.nombre = nombre;
        this.navesEspaciales = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }
    
    
    
    public void agregarNave(Nave nave){
        if(navesEspaciales.contains(nave)){
            throw new NaveYaExisteException();
        }
        navesEspaciales.add(nave);
    }
    
    public void mostrarNaves(){
        for (Nave navesEspacial : navesEspaciales) {
            System.out.println(navesEspacial.toString());
        }
    }
    
    public void iniciarExploracion(){
        for (Nave navesEspacial : navesEspaciales) {
            if(navesEspacial instanceof Exploracion exploracion){
                exploracion.explorar();
            } else {
                System.out.println("La nave " + navesEspacial.getNombre() + " no puede explorar solo transporta pasajeros.");
            }
        }
    }
    
}
