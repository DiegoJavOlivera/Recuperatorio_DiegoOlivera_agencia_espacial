/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaexpedicionesespaciales;

/**
 *
 * @author Diego
 */
public class NaveExploracion extends Nave implements Exploracion{

    private TipoMision mision;

    public NaveExploracion(String nombre, int capacidadTripulacion, int anioLanzamiento, TipoMision mision) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.mision = mision;
    }

    
    @Override
    public String toString() {
        return super.toString() + " Tipo de mision=" + mision + '}';
    }


    
    @Override
    public void explorar() {
        System.out.println(getNombre() + " nave exploradora inicio una exploracion.");
    }
    
    
}
